/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinaria1.pkg0;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ryzen
 */
public class POO {
    
    
    public POO(){
    
    }
    
    
    public void MostrarClientes(JTable tabla){
    
    try{
        DefaultTableModel model = new DefaultTableModel();
        Conexion con = new Conexion();
       ResultSet rs;
       
       
        String Consulta = "Call MostrarClientes();";
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);
        rs = ps.executeQuery(Consulta);
         ResultSetMetaData metadata = rs.getMetaData();
         for (int i = 1; i <=metadata.getColumnCount() ; i++) {
            
            model.addColumn(metadata.getColumnLabel(i));
            
            
            
        }
         
         while(rs.next()){
         Object[] filas =new Object[metadata.getColumnCount()];
         for (int i = 0; i <metadata.getColumnCount() ; i++) {
            filas[i] = rs.getObject(i+1);
            
            
            
            
        }
         model.addRow(filas);
         }
        tabla.setModel(model);
    }
   
    catch(Exception E){
    JOptionPane.showMessageDialog(null, E.toString());
    
    }
    


}




 public void MostrarMascotas(JTable tabla){
    
    try{
        DefaultTableModel model = new DefaultTableModel();
        Conexion con = new Conexion();
       ResultSet rs;
       
       
        String Consulta = " Call MostrarMascotas()";
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);
        rs = ps.executeQuery(Consulta);
         ResultSetMetaData metadata = rs.getMetaData();
         for (int i = 1; i <=metadata.getColumnCount() ; i++) {
            
            model.addColumn(metadata.getColumnLabel(i));
            
            
            
        }
         
         while(rs.next()){
         Object[] filas =new Object[metadata.getColumnCount()];
         for (int i = 0; i <metadata.getColumnCount() ; i++) {
            filas[i] = rs.getObject(i+1);
            
            
            
            
        }
         model.addRow(filas);
         }
        tabla.setModel(model);
    }
   
    catch(Exception E){
    JOptionPane.showMessageDialog(null, E.toString());
    
    }
    


}    
 
 
 public void LlenarComboMetodo(JComboBox ComboMetodo){
        
         try{
                     
                      Conexion con = new Conexion();
                      ResultSet rs;
                      PreparedStatement  ps;
                      String Consulta="Call ComboMetodo();";
                               
                       ps = con.ObtenerConexion().prepareStatement(Consulta);
                       rs = ps.executeQuery();
                       
                       while(rs.next()){
                           ComboMetodo.addItem(rs.getString("Nombre"));
                       }            
         }
                 catch(Exception E){
                         JOptionPane.showMessageDialog(null, E.toString());
                 }
        
    }
     
 
 
 
 
   

public void LlenarTipoConsulta(JComboBox ComboMetodo){
        
         try{
                     
                      Conexion con = new Conexion();
                      ResultSet rs;
                      PreparedStatement  ps;
                      String Consulta="call ComboTipoConsulta();";
                               
                       ps = con.ObtenerConexion().prepareStatement(Consulta);
                       rs = ps.executeQuery();
                       
                       while(rs.next()){
                           ComboMetodo.addItem(rs.getString("Nombre"));
                       }            
         }
                 catch(Exception E){
                         JOptionPane.showMessageDialog(null, E.toString());
                 }
        
    }
     
 


public void Consulta(JTextField  Motivo, int Fk_estado,int Fk_Cliente , int Fk_Mascota, int Fk_TipoConsulta, int Fk_MetodoPago, Date FechaConsulta, int Fk_Usuario){
          try {
        Conexion con = new Conexion();

       
        String Consulta = "Insert into Consulta(Motivo,fk_estado,fk_metodopago,fk_mascotas,fk_tipo_consulta,fk_Cliente,fecha,fk_usuarios) values (?,?,?,?,?,?,?,?)";
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);

       
        ps.setString(1, Motivo.getText());
        ps.setInt(2, Fk_estado);
        ps.setInt(3, Fk_MetodoPago);
        ps.setInt(4, Fk_Mascota);
        ps.setInt(5, Fk_TipoConsulta);
        ps.setInt(6, Fk_Cliente);
        ps.setDate(7, FechaConsulta);
        ps.setInt(8, Fk_Usuario);

        
        int filas = ps.executeUpdate();

        if (filas > 0) {
            
            JOptionPane.showMessageDialog(null, "Se ha registrado una nueva consulta");
            
        } else {
          
        }

    } catch (Exception E) {
        JOptionPane.showMessageDialog(null, E.toString());
    }
}


public void Menu(int Mascota,int Dueño,int ID){
    int Numeros1 =Mascota;
    int Numeros2 = Dueño;
    Principal pri = new Principal(null,Numeros1,Numeros2,ID);
    
    
    
    }

public void Menu2(int Menu){
    int Numeros =Menu;
    Principal pri = new Principal(null,0,Numeros,0);
    
    
    
    }





public void MostrarEnEspera(JTable tabla){
    
    try{
        DefaultTableModel model = new DefaultTableModel();
        Conexion con = new Conexion();
       ResultSet rs;
       
       
        String Consulta = "Call MostrarEnEspera();";
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);
        rs = ps.executeQuery(Consulta);
         ResultSetMetaData metadata = rs.getMetaData();
         for (int i = 1; i <=metadata.getColumnCount() ; i++) {
            
            model.addColumn(metadata.getColumnLabel(i));
            
            
            
        }
         
         while(rs.next()){
         Object[] filas =new Object[metadata.getColumnCount()];
         for (int i = 0; i <metadata.getColumnCount() ; i++) {
            filas[i] = rs.getObject(i+1);
            
            
            
            
        }
         model.addRow(filas);
         }
        tabla.setModel(model);
    }
   
    catch(Exception E){
    
    JOptionPane.showMessageDialog(null, E.toString());
    }
    


}    
 

  public void EstadoConfirmado(int ID){
      
       try {
        Conexion con = new Conexion();

      
        String Consulta2 = "Call EstadoConfirmado(?)";
        PreparedStatement ps2 = con.ObtenerConexion().prepareStatement(Consulta2);

       
        ps2.setInt(1, ID);
        
        int filas2 = ps2.executeUpdate();

        if (filas2 > 0) {
            
            JOptionPane.showMessageDialog(null, "Se confirmó la cita ");
        } else {
            JOptionPane.showMessageDialog(null, "No se pudo hacer ss");
        }

    } catch (Exception E) {
        JOptionPane.showMessageDialog(null, E.toString());
    }
       
      
      
      }
  
  
  
  public void EstadoCancelado(int ID){
      
       try {
        Conexion con = new Conexion();

      
        String Consulta2 = "call EstadoCancelado(?)";
        PreparedStatement ps2 = con.ObtenerConexion().prepareStatement(Consulta2);

       
        ps2.setInt(1, ID);
        
        int filas2 = ps2.executeUpdate();

        if (filas2 > 0) {
            
            JOptionPane.showMessageDialog(null, "Se canceló la cita ");
        } else {
            JOptionPane.showMessageDialog(null, "No se pudo hacer ss");
        }

    } catch (Exception E) {
        JOptionPane.showMessageDialog(null, E.toString());
    }
       
      
      
      }
      




public void MostrarFechas(JTable Tabla,Date Inicio,Date Final){
    try{
        DefaultTableModel model = new DefaultTableModel();
        Conexion con = new Conexion();
       ResultSet rs;
       
       
        String Consulta = "Call MostrarFechas(?,?);";
        
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);
        ps.setDate(1, Inicio);
        ps.setDate(2, Final);
        
        
        rs = ps.executeQuery();
         ResultSetMetaData metadata = rs.getMetaData();
         for (int i = 1; i <=metadata.getColumnCount() ; i++) {
            
            model.addColumn(metadata.getColumnLabel(i));
            
            
            
        }
         
         while(rs.next()){
         Object[] filas =new Object[metadata.getColumnCount()];
         for (int i = 0; i <metadata.getColumnCount() ; i++) {
            filas[i] = rs.getObject(i+1);
            
            
            
            
        }
         model.addRow(filas);
         }
        Tabla.setModel(model);
        
    }
   
    catch(Exception E){
    JOptionPane.showMessageDialog(null, "Ha ocurrido un error "+E.toString());
    
    }



}



public void MostrarGeneralesFechas(JTable Tabla,Date Inicio,Date Final){
    try{
        DefaultTableModel model = new DefaultTableModel();
        Conexion con = new Conexion();
       ResultSet rs;
       
       
        String Consulta = "Call MostrarFechasGenerales(?,?)";
        
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);
        ps.setDate(1, Inicio);
        ps.setDate(2, Final);
        
        
        rs = ps.executeQuery();
         ResultSetMetaData metadata = rs.getMetaData();
         for (int i = 1; i <=metadata.getColumnCount() ; i++) {
            
            model.addColumn(metadata.getColumnLabel(i));
            
            
            
        }
         
         while(rs.next()){
         Object[] filas =new Object[metadata.getColumnCount()];
         for (int i = 0; i <metadata.getColumnCount() ; i++) {
            filas[i] = rs.getObject(i+1);
            
            
            
            
        }
         model.addRow(filas);
         }
        Tabla.setModel(model);
        
    }
   
    catch(Exception E){
    JOptionPane.showMessageDialog(null, "Ha ocurrido un error "+E.toString());
    
    }

    
    
    
    
    
    
    
    
    
    


}


public void LlenarComboTipoAnimal(JComboBox ComboMetodo){
        
         try{
                     
                      Conexion con = new Conexion();
                      ResultSet rs;
                      PreparedStatement  ps;
                      String Consulta="Call ComboAnimales();";
                               
                       ps = con.ObtenerConexion().prepareStatement(Consulta);
                       rs = ps.executeQuery();
                       
                       while(rs.next()){
                           ComboMetodo.addItem(rs.getString("Nombre"));
                       }            
         }
                 catch(Exception E){
                         JOptionPane.showMessageDialog(null, E.toString());
                 }
        
    }
     




    public void LlenarComboRaza(JComboBox ComboMetodo, int ID){
        
         try{
                     
                      Conexion con = new Conexion();
                      ResultSet rs;
                      PreparedStatement  ps;
                      String Consulta=" Call LlenarComboRaza(?)";
                      
                      
                       ps = con.ObtenerConexion().prepareStatement(Consulta);
                       ps.setInt(1, ID);
                       rs = ps.executeQuery();
                       
                       while(rs.next()){
                           ComboMetodo.addItem(rs.getString("Nombre"));
                       }            
         }
                 catch(Exception E){
                         JOptionPane.showMessageDialog(null, E.toString());
                 }
        
    }

    
    
     
    
    
public void NuevoUsuario(String  Nombre,String Apellido, String Documento, Date FechaNacimiento){
          try {
        Conexion con = new Conexion();

       
        String Consulta = "Call NuevoUsuario(?,?,?,?);";
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);

       
        ps.setString(1, Nombre);
        ps.setString(2, Apellido);
        ps.setString(3, Documento);
        ps.setDate(4, FechaNacimiento);
      

        
        int filas = ps.executeUpdate();

        if (filas > 0) {
            
            JOptionPane.showMessageDialog(null, "Se ha registrado un nuevo cliente");
            
        } else {
          
        }

    } catch (Exception E) {
        JOptionPane.showMessageDialog(null, E.toString());
    }
}



  public void NuevaMascota(String  Nombre,String Color, Float Peso, Date FechaNacimiento, int Tipo, int Raza){
          try {
        Conexion con = new Conexion();

       
        String Consulta = "insert into mascotas(Nombre,Peso,Color,Edad,Fk_tipo_Animal,Fk_Raza) values(?,?,?,?,?,?);";
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);

       
        ps.setString(1, Nombre);
        ps.setFloat(2, Peso);
        ps.setString(3, Color);
        ps.setDate(4, FechaNacimiento);
        ps.setInt(5, Tipo);
        ps.setInt(6, Raza);
      

        
        int filas = ps.executeUpdate();

        if (filas > 0) {
            
            JOptionPane.showMessageDialog(null, "Se ha registrado una nueva mascota");
            
        } else {
          
        }

    } catch (Exception E) {
        JOptionPane.showMessageDialog(null, E.toString());
    }
}
 
  
  public void ObtenerIndiceMascota(String Nombre){
        
         try{
                     
                      Conexion con = new Conexion();
                   
                     ResultSet rs;
                       PreparedStatement  ps;
                       
                       String Consulta="Call ObtenerIndiceMascota(?)";
                               
                       ps = con.ObtenerConexion().prepareStatement(Consulta);
                       ps.setString(1, Nombre); 
                       
                       
                       
                       
                    
                       
                       
                       rs = ps.executeQuery();
                       
                       if(rs.next()){
                           
                      int    IDNombre = rs.getInt("ID_raza");
                      FrmRegistrarMascota re = new FrmRegistrarMascota(null,true,IDNombre);
                      
                      
                         
                        
                        
                            
                       
                        
                       }
                       
                      else {
                       JOptionPane.showMessageDialog(null, "Ha fallado algo");
                    
                     
                    
                 
                     
                     
                 }
         }
                 catch(Exception E){
                         JOptionPane.showMessageDialog(null, E.toString());
                         
                 
                 }
         
         
                 
    
    
    
    
    
    
   
    
        
    }

  

    public void MostrarDinero(JTable tabla){
    
    try{
        DefaultTableModel model = new DefaultTableModel();
        Conexion con = new Conexion();
       ResultSet rs;
       
       
        String Consulta = "Call MostrarDinero()";
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);
        rs = ps.executeQuery(Consulta);
         ResultSetMetaData metadata = rs.getMetaData();
         for (int i = 1; i <=metadata.getColumnCount() ; i++) {
            
            model.addColumn(metadata.getColumnLabel(i));
            
            
            
        }
         
         while(rs.next()){
         Object[] filas =new Object[metadata.getColumnCount()];
         for (int i = 0; i <metadata.getColumnCount() ; i++) {
            filas[i] = rs.getObject(i+1);
            
            
            
            
        }
         model.addRow(filas);
         }
        tabla.setModel(model);
    }
   
    catch(Exception E){
    JOptionPane.showMessageDialog(null, E.toString());
    
    }
    


}


  public void LlenarComboVeterinario(JComboBox ComboMetodo){
        
         try{
                     
                      Conexion con = new Conexion();
                      ResultSet rs;
                      PreparedStatement  ps;
                      String Consulta="call LlenarComboVete();";
                      
                      
                       ps = con.ObtenerConexion().prepareStatement(Consulta);
                   
                       rs = ps.executeQuery();
                       
                       while(rs.next()){
                           ComboMetodo.addItem(rs.getString("Nombre"));
                       }            
         }
                 catch(Exception E){
                         JOptionPane.showMessageDialog(null, E.toString());
                 }
        
    }

  
  public void MostrarVeterinario(JTable Tabla,int Mes, int IDVeterinario){
    try{
        DefaultTableModel model = new DefaultTableModel();
        Conexion con = new Conexion();
       ResultSet rs;
       
       
        String Consulta = "Call TablaVete(?,?)";
        
        PreparedStatement ps = con.ObtenerConexion().prepareStatement(Consulta);
        ps.setInt(1, Mes);
        ps.setInt(2, IDVeterinario);
      
        
        rs = ps.executeQuery();
         ResultSetMetaData metadata = rs.getMetaData();
         for (int i = 1; i <=metadata.getColumnCount() ; i++) {
            
            model.addColumn(metadata.getColumnLabel(i));
            
            
            
        }
         
         while(rs.next()){
         Object[] filas =new Object[metadata.getColumnCount()];
         for (int i = 0; i <metadata.getColumnCount() ; i++) {
            filas[i] = rs.getObject(i+1);
            
            
            
            
        }
         model.addRow(filas);
         }
        Tabla.setModel(model);
        
    }
   
    catch(Exception E){
    JOptionPane.showMessageDialog(null, "Ha ocurrido un error "+E.toString());
    
    }



}
  
}

