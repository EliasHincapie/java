/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinaria1.pkg0;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author ryzen
 */
public class Conexion {
  
     static String url = "jdbc:mysql://localhost/veterinaria";
    static String username = "root";
    static String password = "cbn2016";
    Connection Conexion;
    
    
    public Connection ObtenerConexion(){
    
    try{
    Conexion = DriverManager.getConnection(url,username,password);
    
  
    
    }
    
    catch(Exception E){
    
    JOptionPane.showMessageDialog(null, "Ha ocurrido un error "+E.toString());
    
    }
    
    return Conexion;
    
    }
    
    
    
    
   
    
    
    
    
}
